from __future__ import annotations
import hashlib, os
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FILES={
    'app_core.py':('dda00b3b928818465b945175e3c63301434dc1bf77d9c2c38cf53eb4e4e93bc5','ee9352acd0ad64720ffa99bf637dbb2b6cf3dd4a57d32fe450d18cda1aa3863b'),
    'sorter_seek.py':('c67f95eda3714fba923d96afa4e436a63d85d850930563e6eea16bf1f31e36c8','75f2bb1b1039f784cba85cc23224dcd4766dac639b1eb94dfdb3c5527288e139'),
}

def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def patch_core(s:str)->str:
    pairs=[
        ('APP_VERSION = "3.24.3 Direct ZIP OTA"','APP_VERSION = "3.24.4 No Console Flash"'),
        ('FFPROBE_EXE = shutil.which("ffprobe")\n','FFPROBE_EXE = shutil.which("ffprobe")\nSUBPROCESS_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0\n'),
        ("subprocess.run(cmd, capture_output=True, text=True, errors='replace', timeout=35)","subprocess.run(cmd, capture_output=True, text=True, errors='replace', timeout=35, creationflags=SUBPROCESS_NO_WINDOW)"),
        ("subprocess.run(cmd, capture_output=True, text=True, timeout=35)","subprocess.run(cmd, capture_output=True, text=True, timeout=35, creationflags=SUBPROCESS_NO_WINDOW)"),
        ("subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=40)","subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=40, creationflags=SUBPROCESS_NO_WINDOW)"),
        ("subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,errors='replace',timeout=max(60,int((row['duration'] or 60)*0.45)))","subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,errors='replace',timeout=max(60,int((row['duration'] or 60)*0.45)),creationflags=SUBPROCESS_NO_WINDOW)"),
    ]
    for old,new in pairs:
        if old not in s: raise RuntimeError('app_core patch anchor missing')
        s=s.replace(old,new,1)
    return s

def patch_seek(s:str)->str:
    pairs=[
        ("TS_FORMAT_TOKENS={'mpegts','mpegtsraw'}\n","TS_FORMAT_TOKENS={'mpegts','mpegtsraw'}\nSUBPROCESS_NO_WINDOW=getattr(subprocess,'CREATE_NO_WINDOW',0) if os.name=='nt' else 0\n"),
        ("timeout=max(5,int(timeout_per_point)))","timeout=max(5,int(timeout_per_point)),creationflags=SUBPROCESS_NO_WINDOW)"),
        ("],capture_output=True,text=True,errors='replace',timeout=timeout)","],capture_output=True,text=True,errors='replace',timeout=timeout,creationflags=SUBPROCESS_NO_WINDOW)"),
        ("[ffmpeg_exe,'-hide_banner','-i',source],capture_output=True,text=True,errors='replace',timeout=timeout)","[ffmpeg_exe,'-hide_banner','-i',source],capture_output=True,text=True,errors='replace',timeout=timeout,creationflags=SUBPROCESS_NO_WINDOW)"),
        ("errors='replace',timeout=timeout)\n        if p.returncode!=0","errors='replace',timeout=timeout,creationflags=SUBPROCESS_NO_WINDOW)\n        if p.returncode!=0"),
        ("errors='replace',timeout=20)\n        return p.returncode","errors='replace',timeout=20,creationflags=SUBPROCESS_NO_WINDOW)\n        return p.returncode"),
        ("errors='replace',timeout=timeout)\n            if p.returncode==0 and tmp.exists()","errors='replace',timeout=timeout,creationflags=SUBPROCESS_NO_WINDOW)\n            if p.returncode==0 and tmp.exists()"),
        ("timeout=max(3,int(timeout)))\n    except Exception","timeout=max(3,int(timeout)),creationflags=SUBPROCESS_NO_WINDOW)\n    except Exception"),
    ]
    for old,new in pairs:
        if old not in s: raise RuntimeError('sorter_seek patch anchor missing')
        s=s.replace(old,new,1)
    return s

try:
    core=ROOT/'app_core.py'; seek=ROOT/'sorter_seek.py'
    states={name:sha(ROOT/name) for name in FILES}
    if all(states[n]==FILES[n][1] for n in FILES):
        pass
    elif all(states[n]==FILES[n][0] for n in FILES):
        new_core=patch_core(core.read_text(encoding='utf-8'))
        new_seek=patch_seek(seek.read_text(encoding='utf-8'))
        if hashlib.sha256(new_core.encode('utf-8')).hexdigest()!=FILES['app_core.py'][1]: raise RuntimeError('app_core patched hash mismatch')
        if hashlib.sha256(new_seek.encode('utf-8')).hexdigest()!=FILES['sorter_seek.py'][1]: raise RuntimeError('sorter_seek patched hash mismatch')
        for path,text in ((core,new_core),(seek,new_seek)):
            tmp=path.with_suffix(path.suffix+'.3244.tmp');tmp.write_text(text,encoding='utf-8');os.replace(tmp,path)
    else:
        raise RuntimeError('v3.24.4 hotfix refused: installation files are not the v3.24.3 baseline')
finally:
    try:Path(__file__).unlink(missing_ok=True)
    except Exception:pass
