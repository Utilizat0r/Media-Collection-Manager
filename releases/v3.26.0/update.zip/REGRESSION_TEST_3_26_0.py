from pathlib import Path
import hashlib,sys,types
ROOT=Path(__file__).resolve().parent

def sha(n):return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
assert sha('sorter_seek.py')=='c67f95eda3714fba923d96afa4e436a63d85d850930563e6eea16bf1f31e36c8'
assert sha('spider_state.py')=='598bfecd3353ef634dc34fbe425b8a95f528341fa9c06cf4615931ba0aa48e0c'
assert sha('sorter_native_player.py')=='1778fc9045394cc2ba35aadea07f72b3c89bce437a5b0bdbb2e387969629c546'
sys.modules.setdefault('imagehash',types.ModuleType('imagehash'))
sys.path.insert(0,str(ROOT))
import ai_engine
cases={
'белые чулки и черный лифчик':[('stockings','white'),('bra','black')],
'белые чулки черный лифчик':[('stockings','white'),('bra','black')],
'красное платье + белые чулки + черный лифчик':[('dress','red'),('stockings','white'),('bra','black')],
'кружевное черное белье белые чулки красная юбка':[('underwear','black'),('stockings','white'),('skirt','red')],
}
for q,want in cases.items():
    b=ai_engine._query_plan(q)['features']['bindings'];got=[(x['object'],x['color']) for x in b]
    assert got==want,(q,got,want)
assert 'headphones' in [x.casefold() for x in ai_engine._all_object_distractors()]
print('REGRESSION_TEST_3_26_0: PASS')
