from __future__ import annotations
import hashlib,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FILES={
'ai_engine.py':('40a2681c9f8f468dd98fa27159ad1d2fb36867f5e343024e6557eb3f6acb5cca','e565c36f3b15e8762536501214b3ac3f0773742b1b6dd4d5bb8224565c322d30'),
'app_core.py':('cbd0b773ba211e98b3ece25df3536d347fccc5512962034f0c765d0db22fe11b','a8d2281ee618ec1caf9af67d90721986f5d0b9824c51ebe38c27647bfd3edc42'),
}
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,s):
 b=s.encode('utf-8');target=FILES[n][1]
 if sha(b)!=target:raise RuntimeError(f'{n} target hash mismatch {sha(b)}')
 p=ROOT/n;t=p.with_suffix(p.suffix+'.3260.tmp');t.write_bytes(b);os.replace(t,p)
def patch_ai(s):
 old='def _object_bindings(positive_query: str, concepts: list[dict]) -> list[dict]:\n    """Bind colour/material modifiers to the object in the same phrase clause.\n\n    `красное платье и чёрные чулки` therefore becomes two independent bindings instead\n    of a bag of global attributes.  This is deliberately clause based: it is predictable\n    for user-entered search phrases and avoids pretending we have a full Russian parser.\n    """\n    objects=[x for x in concepts if x.get(\'category\')==\'object\']\n    if not objects:return []\n    clauses=[]\n    cursor=0\n    # Strong conjunctions delimit independently described objects. Do not split generic\n    # locative phrases such as "на кровати перед зеркалом".\n    for m in re.finditer(r\'(?iu)\\s+(?:и|and)\\s+|[,;]+\',positive_query):\n        part=positive_query[cursor:m.start()].strip()\n        if part:clauses.append(part)\n        cursor=m.end()\n    part=positive_query[cursor:].strip()\n    if part:clauses.append(part)\n    if not clauses:clauses=[positive_query]\n    out=[];bound_keys=set()\n    for clause in clauses:\n        folded=_fold_query(clause)\n        cs=_matched_specs(folded,_COLOR_SPECS)\n        ats=_matched_specs(folded,_ATTRIBUTE_SPECS)\n        obs=[x for x in _matched_specs(folded,_CONCEPT_SPECS) if x.get(\'category\')==\'object\']\n        for obj in obs:\n            key=str(obj.get(\'key\') or \'\')\n            out.append({\'object\':obj,\'color\':cs[0] if cs else None,\'attributes\':ats,\'clause\':clause})\n            bound_keys.add(key)\n    # Objects not isolated by a conjunction still remain mandatory. Bind a global colour\n    # only when the query has exactly one object; never smear it over multiple nouns.\n    if len(objects)==1 and not out:\n        folded=_fold_query(positive_query)\n        out=[{\'object\':objects[0],\'color\':(_matched_specs(folded,_COLOR_SPECS) or [None])[0],\n              \'attributes\':_matched_specs(folded,_ATTRIBUTE_SPECS),\'clause\':positive_query}]\n    elif len(objects)==1 and out:\n        pass\n    else:\n        for obj in objects:\n            if str(obj.get(\'key\') or \'\') not in bound_keys:\n                out.append({\'object\':obj,\'color\':None,\'attributes\':[],\'clause\':positive_query})\n    return out\n'
 new='def _spec_position(folded: str, spec: dict) -> int:\n    """Earliest mention of a known semantic spec in a folded user clause."""\n    hits=[_needle_position(folded,n) for n in (spec.get(\'needles\') or ())]\n    hits=[x for x in hits if x>=0]\n    return min(hits) if hits else -1\n\n\ndef _object_bindings(positive_query: str, concepts: list[dict]) -> list[dict]:\n    """Bind each modifier to its nearest object, for an arbitrary number of objects.\n\n    Conjunctions/commas remain useful clause boundaries, but correctness no longer depends\n    on them: `белые чулки черный лифчик` is resolved by mention positions rather than by\n    taking the first colour in the whole phrase. This scales to N object+attribute pairs.\n    """\n    objects=[x for x in concepts if x.get(\'category\')==\'object\']\n    if not objects:return []\n    # Strong separators only. Position matching below handles missing punctuation/conjunctions.\n    clauses=[];cursor=0\n    for m in re.finditer(r\'(?iu)\\s+(?:и|and)\\s+|\\s*[+&/]\\s*|[,;]+\',positive_query):\n        part=positive_query[cursor:m.start()].strip()\n        if part:clauses.append(part)\n        cursor=m.end()\n    part=positive_query[cursor:].strip()\n    if part:clauses.append(part)\n    if not clauses:clauses=[positive_query]\n    out=[];bound_keys=set()\n    for clause in clauses:\n        folded=_fold_query(clause)\n        cs=_matched_specs(folded,_COLOR_SPECS);ats=_matched_specs(folded,_ATTRIBUTE_SPECS)\n        obs=[x for x in _matched_specs(folded,_CONCEPT_SPECS) if x.get(\'category\')==\'object\']\n        if not obs:continue\n        obj_pos={str(o.get(\'key\') or \'\'):_spec_position(folded,o) for o in obs}\n        color_for={str(o.get(\'key\') or \'\'):[] for o in obs};attr_for={str(o.get(\'key\') or \'\'):[] for o in obs}\n        def nearest_obj(spec):\n            pos=_spec_position(folded,spec)\n            if pos<0:return obs[0]\n            after=[o for o in obs if obj_pos[str(o.get(\'key\') or \'\')]>=pos]\n            before=[o for o in obs if obj_pos[str(o.get(\'key\') or \'\')]<pos]\n            if after:\n                nxt=min(after,key=lambda o:obj_pos[str(o.get(\'key\') or \'\')]-pos);nd=obj_pos[str(nxt.get(\'key\') or \'\')]-pos\n                if not before:return nxt\n                prv=max(before,key=lambda o:obj_pos[str(o.get(\'key\') or \'\')]);pd=pos-obj_pos[str(prv.get(\'key\') or \'\')]\n                # Adjectival modifiers normally precede their noun; allow a modest gap so\n                # `белые чулки черный лифчик` binds black->bra, not black->stockings.\n                if nd<=pd+12:return nxt\n            return min(obs,key=lambda o:abs(obj_pos[str(o.get(\'key\') or \'\')]-pos))\n        for c in cs:color_for[str(nearest_obj(c).get(\'key\') or \'\')].append(c)\n        for a in ats:attr_for[str(nearest_obj(a).get(\'key\') or \'\')].append(a)\n        for obj in obs:\n            key=str(obj.get(\'key\') or \'\');assigned_colors=color_for.get(key) or []\n            out.append({\'object\':obj,\'color\':assigned_colors[0] if assigned_colors else None,\n                        \'attributes\':attr_for.get(key) or [],\'clause\':clause})\n            bound_keys.add(key)\n    # Every requested object is mandatory even if a clause could not be isolated.\n    for obj in objects:\n        key=str(obj.get(\'key\') or \'\')\n        if key not in bound_keys:out.append({\'object\':obj,\'color\':None,\'attributes\':[],\'clause\':positive_query})\n    return out\n'
 if old not in s:raise RuntimeError('object binding anchor missing')
 s=s.replace(old,new,1)
 old="_SEARCH_MODES = {'strict','balanced','wide','all'}\n\n\ndef _fold_query"
 new='_SEARCH_MODES = {\'strict\',\'balanced\',\'wide\',\'all\'}\n\n\ndef _all_object_distractors() -> tuple[str,...]:\n    """Dynamic distractor vocabulary derived from the registered object taxonomy.\n\n    The static list keeps useful near-class phrases (for example bikini top/pantyhose),\n    while every present/future object spec automatically participates without adding a\n    hand-written pairwise rule.\n    """\n    vals=list(_OBJECT_DISTRACTORS)\n    for spec in _CONCEPT_SPECS:\n        if spec.get(\'category\')==\'object\':vals.extend(spec.get(\'en\') or ())\n    out=[];seen=set()\n    for x in vals:\n        k=str(x).casefold().strip()\n        if k and k not in seen:seen.add(k);out.append(str(x))\n    return tuple(out)\n\n\n'+'def _fold_query'
 if old not in s:raise RuntimeError('dynamic distractor anchor missing')
 s=s.replace(old,new,1)
 old="wearable_alts={str(x).casefold() for x in _OBJECT_DISTRACTORS}\n"
 new="object_distractors=_all_object_distractors();wearable_alts={str(x).casefold() for x in object_distractors}\n"
 if old not in s:raise RuntimeError('distractor set anchor missing')
 s=s.replace(old,new,1)
 old="        for alt in _OBJECT_DISTRACTORS:\n";new="        for alt in object_distractors:\n"
 if old not in s:raise RuntimeError('distractor loop anchor missing')
 return s.replace(old,new,1)
def patch_core(s):
 old='APP_VERSION = "3.25.0 Performance Core"';new='APP_VERSION = "3.26.0 Universal AI Search"'
 if old not in s:raise RuntimeError('version anchor missing')
 return s.replace(old,new,1)
ok=True
try:
 for n,fn in [('ai_engine.py',patch_ai),('app_core.py',patch_core)]:
  p=ROOT/n;got=sha(p.read_bytes());base,target=FILES[n]
  if got==target:continue
  if got!=base:raise RuntimeError(f'{n} unexpected source hash {got}')
  put(n,fn(p.read_text(encoding='utf-8')))
except Exception as exc:
 ok=False
 try:
  log=Path.home()/'.media_collection_manager'/'logs'/'update_patch_3260_error.txt';log.parent.mkdir(parents=True,exist_ok=True);log.write_text(str(exc),encoding='utf-8')
 except Exception:pass
finally:
 if ok:
  try:Path(__file__).unlink(missing_ok=True)
  except Exception:pass
