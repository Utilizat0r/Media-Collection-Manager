from pathlib import Path

root = Path(__file__).resolve().parent

NEW_DOWNLOAD = r'''def download_package(manifest: dict, dest_dir: str | Path, progress=None, status=None) -> Path:
    url = str(manifest.get('url') or '').strip()
    expected = str(manifest.get('sha256') or '').lower().strip()
    if not url or len(expected) != 64:
        raise RuntimeError('\u041d\u0435\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u044b\u0439 manifest \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f')

    root = Path(dest_dir)
    root.mkdir(parents=True, exist_ok=True)
    final = root / f"mcm_update_{manifest.get('version', 'new')}.zip"
    part = final.with_suffix('.part')
    status_path = root / f"update_progress_{uuid.uuid4().hex}.json"
    try:
        part.unlink(missing_ok=True)
    except Exception:
        pass

    _atomic_json(status_path, {'state': 'running', 'phase': 'connect', 'detail': '\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043a GitHub\u2026', 'done': 0, 'total': 0})
    _start_download_progress_window(status_path, str(manifest.get('version') or ''), root)

    def emit_phase(phase: str, detail: str = '', done: int = 0, total: int = 0):
        _atomic_json(status_path, {'state': 'running', 'phase': phase, 'detail': detail, 'done': int(done or 0), 'total': int(total or 0)})
        if status:
            try:
                status(str(phase), str(detail))
            except Exception:
                pass

    def emit_progress(done: int, total: int, detail: str = ''):
        _atomic_json(status_path, {'state': 'running', 'phase': 'download', 'detail': detail, 'done': int(done or 0), 'total': int(total or 0)})
        if progress:
            try:
                progress(int(done or 0), int(total or 0))
            except Exception:
                pass

    try:
        h = hashlib.sha256()
        req = urllib.request.Request(url, headers={
            'User-Agent': USER_AGENT,
            'Cache-Control': 'no-cache',
            'Accept': 'application/octet-stream',
        })
        with urllib.request.urlopen(req, timeout=60) as response, part.open('wb') as f:
            total = int(response.headers.get('Content-Length') or 0)
            done = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                h.update(chunk)
                done += len(chunk)
                emit_progress(done, total, '')

        emit_phase('verify', '\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 SHA-256\u2026')
        if h.hexdigest().lower() != expected:
            try:
                part.unlink()
            except Exception:
                pass
            raise RuntimeError('SHA-256 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u043d\u0435 \u0441\u043e\u0432\u043f\u0430\u0434\u0430\u0435\u0442')

        emit_phase('archive', '\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0446\u0435\u043b\u043e\u0441\u0442\u043d\u043e\u0441\u0442\u0438 ZIP\u2026')
        os.replace(part, final)
        with zipfile.ZipFile(final, 'r') as archive:
            bad = archive.testzip()
            if bad:
                raise RuntimeError('\u041f\u043e\u0432\u0440\u0435\u0436\u0434\u0451\u043d \u0444\u0430\u0439\u043b \u0432\u043d\u0443\u0442\u0440\u0438 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f: ' + str(bad))

        _atomic_json(status_path, {'state': 'done', 'phase': 'ready', 'detail': '\u041f\u0430\u043a\u0435\u0442 \u043f\u0440\u043e\u0432\u0435\u0440\u0435\u043d. \u041d\u0430\u0447\u0438\u043d\u0430\u044e \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0443\u2026', 'done': 100, 'total': 100})
        return final
    except Exception as exc:
        _atomic_json(status_path, {'state': 'error', 'phase': 'error', 'detail': str(exc), 'done': 0, 'total': 1})
        raise
'''

try:
    p = root / 'app_core.py'
    s = p.read_text(encoding='utf-8')
    for old in (
        'APP_VERSION = "3.24.2 Update Progress UX"',
        'APP_VERSION = "3.24.1 Playback Recovery Hotfix"',
    ):
        if old in s:
            s = s.replace(old, 'APP_VERSION = "3.24.3 Direct ZIP OTA"', 1)
            p.write_text(s, encoding='utf-8')
            break
except Exception:
    pass

try:
    p = root / 'updater.py'
    s = p.read_text(encoding='utf-8')
    s = s.replace('import base64\n', '', 1)
    s = s.replace("USER_AGENT = 'MediaCollectionManager-Updater/1.1'", "USER_AGENT = 'MediaCollectionManager-Updater/1.2'", 1)
    start = s.index('def download_package(')
    end = s.index('\ndef launch_installer(', start)
    s = s[:start] + NEW_DOWNLOAD + '\n' + s[end + 1:]
    s = s.replace("'decode':'\u041f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u043f\u0430\u043a\u0435\u0442\u0430\u2026',", '', 1)
    p.write_text(s, encoding='utf-8')
except Exception:
    pass

try:
    Path(__file__).unlink(missing_ok=True)
except Exception:
    pass

# pad xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0018
