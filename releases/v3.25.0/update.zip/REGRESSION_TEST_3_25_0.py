from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent

def sha(n): return hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
protected={
'sorter_seek.py':'c67f95eda3714fba923d96afa4e436a63d85d850930563e6eea16bf1f31e36c8',
'ai_engine.py':'40a2681c9f8f468dd98fa27159ad1d2fb36867f5e343024e6557eb3f6acb5cca',
'spider_state.py':'598bfecd3353ef634dc34fbe425b8a95f528341fa9c06cf4615931ba0aa48e0c',
'sorter_native_player.py':'1778fc9045394cc2ba35aadea07f72b3c89bce437a5b0bdbb2e387969629c546',
}
for n,h in protected.items(): assert sha(n)==h,(n,sha(n),h)
ui=(ROOT/'ui.py').read_text(encoding='utf-8')
core=(ROOT/'app_core.py').read_text(encoding='utf-8')
assert 'APP_VERSION = "3.25.0 Performance Core"' in core
assert 'def _prepare_render_image(self,image: QImage,render_tile:int):' in ui
assert 'final=QPixmap.fromImage(image)' in ui
assert 'if role==ROLE_THUMB:self._queue_page_for_row(index.row())' in ui
assert 'visible_set=self._visible_thumb_paths' in ui
assert 'for req in list(self._thumb_pending.keys()):' in ui
# GUI paint hot-path must no longer allocate smooth-scaled pixmaps in the two fit branches.
assert "scaled=pix.scaled(rect.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)" not in ui
print('REGRESSION_TEST_3_25_0: PASS')
