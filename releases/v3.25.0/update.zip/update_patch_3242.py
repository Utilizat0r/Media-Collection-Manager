from __future__ import annotations
import hashlib, os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FILES={
'ui.py':('e13e6b85884f80ad5c9e3ab4117aae0547cdef51d9ab4f387d56064d6b288377','c60ceb5976d03715ae05b7aeaafa0edbacdd415ede9cd141802486b3a6fea4df'),
'app_core.py':('0d6f090c2d8378e4f9a51b111527152b0172368015cc453a5731a9ff3ef93c48','cbd0b773ba211e98b3ece25df3536d347fccc5512962034f0c765d0db22fe11b'),
}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return (ROOT/n).read_text(encoding='utf-8')
def write_checked(n,s):
    b=s.encode('utf-8'); target=FILES[n][1]
    if sha(b)!=target:raise RuntimeError(f'{n}: target hash mismatch {sha(b)}')
    p=ROOT/n;t=p.with_suffix(p.suffix+'.3250.tmp');t.write_bytes(b);os.replace(t,p)
def patch_core(s):
    old='APP_VERSION = "3.24.5 Sort PRO Recovery"';new='APP_VERSION = "3.25.0 Performance Core"'
    if old not in s:raise RuntimeError('core version anchor missing')
    return s.replace(old,new,1)
def patch_ui(s):
    a='''        return reader.read()\n\n    def run(self):'''
    b='''        return reader.read()\n\n    def _prepare_render_image(self,image: QImage,render_tile:int):\n        """Finish resize/crop in the decoder thread so GUI paint stays cheap."""\n        if image is None or image.isNull():return QImage()\n        if self.proportional_mode:\n            limit=QSize(int(render_tile*3.2),int(render_tile*3.2))\n            return image.scaled(limit,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n        if self.fit_mode:\n            return image.scaled(QSize(render_tile,render_tile),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n        scaled=image.scaled(QSize(render_tile,render_tile),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)\n        if scaled.isNull():return scaled\n        sx=max(0,(scaled.width()-render_tile)//2);sy=max(0,(scaled.height()-render_tile)//2)\n        return scaled.copy(sx,sy,min(render_tile,scaled.width()),min(render_tile,scaled.height()))\n\n    def run(self):'''
    if a not in s:raise RuntimeError('decoder anchor missing')
    s=s.replace(a,b,1)
    a='''                image=self._decode_level(path,level)\n                if self._stop:break\n                if image is not None and not image.isNull():self.image_ready.emit(path,image,render_tile,self.fit_mode)'''
    b='''                image=self._decode_level(path,level)\n                if self._stop:break\n                image=self._prepare_render_image(image,render_tile)\n                if self._stop:break\n                if image is not None and not image.isNull():self.image_ready.emit(path,image,render_tile,self.fit_mode)'''
    if a not in s:raise RuntimeError('decode run anchor missing')
    s=s.replace(a,b,1)
    a='''        pix=QPixmap.fromImage(image)\n        if pix.isNull():return False\n        if target_prop:\n            final=pix.scaled(QSize(int(render_tile*3.2),int(render_tile*3.2)),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n        elif target_fit:\n            final=pix.scaled(QSize(render_tile,render_tile),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n        else:\n            scaled=pix.scaled(QSize(render_tile,render_tile),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation)\n            sx=max(0,(scaled.width()-render_tile)//2);sy=max(0,(scaled.height()-render_tile)//2)\n            final=scaled.copy(sx,sy,min(render_tile,scaled.width()),min(render_tile,scaled.height()))'''
    if a not in s:raise RuntimeError('cache resize anchor missing')
    s=s.replace(a,'        final=QPixmap.fromImage(image)',1)
    a='''                scaled=pix.scaled(rect.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n                painter.drawPixmap(rect.x()+(rect.width()-scaled.width())//2,rect.y()+(rect.height()-scaled.height())//2,scaled)'''
    b='''                pw=max(1,pix.width());ph=max(1,pix.height());scale=min(rect.width()/pw,rect.height()/ph)\n                tw=max(1,int(pw*scale));th=max(1,int(ph*scale));target=QRect(rect.x()+(rect.width()-tw)//2,rect.y()+(rect.height()-th)//2,tw,th)\n                painter.drawPixmap(target,pix,pix.rect())'''
    if a not in s:raise RuntimeError('prop paint anchor missing')
    s=s.replace(a,b,1)
    a='''            scaled=pix if pix.width()<=rect.width() and pix.height()<=rect.height() else pix.scaled(rect.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)\n            painter.drawPixmap(rect.x()+(rect.width()-scaled.width())//2,rect.y()+(rect.height()-scaled.height())//2,scaled)'''
    b='''            pw=max(1,pix.width());ph=max(1,pix.height());scale=min(1.0,rect.width()/pw,rect.height()/ph)\n            tw=max(1,int(pw*scale));th=max(1,int(ph*scale));target=QRect(rect.x()+(rect.width()-tw)//2,rect.y()+(rect.height()-th)//2,tw,th)\n            painter.drawPixmap(target,pix,pix.rect())'''
    if a not in s:raise RuntimeError('fit paint anchor missing')
    s=s.replace(a,b,1)
    a="        if r is None:\n            self._queue_page_for_row(index.row())\n            if role==Qt.ItemDataRole.DisplayRole:return ''\n"
    b="        if r is None:\n            if role==ROLE_THUMB:self._queue_page_for_row(index.row())\n            if role==Qt.ItemDataRole.DisplayRole:return ''\n"
    if a not in s:raise RuntimeError('sparse role anchor missing')
    s=s.replace(a,b,1)
    a='            self._visible_thumb_paths=set(visible);self._visible_thumb_rows=visible_rows\n'
    b='''            self._visible_thumb_paths=set(visible);self._visible_thumb_rows=visible_rows\n            visible_set=self._visible_thumb_paths\n            for req in list(self._thumb_pending.keys()):\n                try:\n                    if str(req[0]) not in visible_set:\n                        self._thumb_pending.pop(req,None)\n                        self.web_delegate.release_request(req[0],req[1],req[2],req[3])\n                except Exception:\n                    self._thumb_pending.pop(req,None)\n'''
    if a not in s:raise RuntimeError('visible queue anchor missing')
    s=s.replace(a,b,1)
    a='''        if reversed_dir or big_jump:\n            self._thumb_generation+=1;self._thumb_prefetch.clear()\n'''
    b='''        if reversed_dir or big_jump:\n            self._thumb_generation+=1;self._thumb_prefetch.clear()\n            for req in list(self._thumb_pending.keys()):\n                self._thumb_pending.pop(req,None)\n                try:self.web_delegate.release_request(req[0],req[1],req[2],req[3])\n                except Exception:pass\n'''
    if a not in s:raise RuntimeError('jump queue anchor missing')
    s=s.replace(a,b,1)
    return s
ok=True
try:
    for n,fn in [('ui.py',patch_ui),('app_core.py',patch_core)]:
        p=ROOT/n;got=sha(p.read_bytes());base,target=FILES[n]
        if got==target:continue
        if got!=base:raise RuntimeError(f'{n}: unexpected source hash {got}')
        write_checked(n,fn(read(n)))
except Exception as exc:
    ok=False
    try:
        log=Path.home()/'.media_collection_manager'/'logs'/'update_patch_3250_error.txt';log.parent.mkdir(parents=True,exist_ok=True);log.write_text(str(exc),encoding='utf-8')
    except Exception:pass
finally:
    if ok:
        try:Path(__file__).unlink(missing_ok=True)
        except Exception:pass
